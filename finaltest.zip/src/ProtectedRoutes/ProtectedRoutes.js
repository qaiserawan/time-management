import React from 'react'
import { Route, withRouter } from 'react-router-dom'
const ProtectedRoute = ({ component: Component, ...rest }) => {
//   console.log('test')
  return (
    <Route
      {...rest}
      render={(props) => {
        const token = localStorage.getItem('token')
        // console.log('token', token)
        if (token) {
          return <Component {...props} />
        } else {
          props.history.push('/')
        }
      }}
    />
  )
}
export default withRouter(ProtectedRoute)