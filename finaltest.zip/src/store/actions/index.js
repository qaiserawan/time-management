import LogInUser from './LogInAction'
// import createUsers from './UserAction'
// import createLogs from './UserAction'
const allActions = {
    LogInUser,
    // createUsers,
    // createLogs
}

export default allActions