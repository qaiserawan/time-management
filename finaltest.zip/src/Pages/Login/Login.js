import React from 'react'
import LogIn from '../../components/Widgets/LogIn'
// import Header from '../../components/Header/Header'
// import styles from './Login.module.css'

const Login = () => {
    return (
        <div>
            {/* <h2>Login Page</h2> */}
            {/* <Header /> */}
            <LogIn />
        </div>
    )
}

export default Login
