import React from 'react'
import Header from '../../../components/Header/Header'
import Dashboard from '../../../components/Dashboard/Dashboard'
// import SignIn from '../../../components/SignIn/SignIn'
// import styles from './Home.module.css'
import 'bootstrap/dist/css/bootstrap.min.css';
// import LogIn from '../../../components/Widgets/LogIn'

const Home = () => {
    return (
        <div>
            <Header />
            <Dashboard />
            {/* <LogIn /> */}

        </div>
    )
}

export default Home
