import React, {useState, useEffect} from 'react'
import styles from './UserList.module.css'
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
// import { getLogs } from '../../../store/actions/UserAction'
import { getUsers } from '../../../store/actions/ManagerActions'
import DeleteUserPopUp from '../../../components/Widgets/DeleteUserPopUp'
// import SignUp from '../../../components/SignUp/SignUp'
// import CreateUser from '../../../components/Widgets/CreateUser'

import { Trash } from 'react-bootstrap-icons'

const UserList = () => {
    const UsersData = useSelector(state => state.managerReducer)
    const dispatch = useDispatch()
    const [delPop, setDelPop] = useState("")
    const delcheck = (id) => {
        setDelPop(id)
    }
    const handlecloseId=()=>{
        setDelPop("")
    }
    // console.log("User data:", UsersData);
    useEffect(() => {
        dispatch(getUsers())
    }, [])
    return (
        <div className="container">
            <div className={styles.Headingss}>
                {delPop&&<DeleteUserPopUp id={delPop} handlecloseId={handlecloseId} />}
                {/* <div><h2>All Users</h2></div>
                <div>
                    <button><SignUp /></button>
                    <button><CreateUser /></button>
                </div> */}
            </div>
            <table className={styles.UserLogList}>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody className={styles.UserFlag}>
                    {
                        UsersData.users.map((item, index) => {
                            return(
                                <tr key={index}>
                                    <td>{item.firstName}</td>
                                    <td>{item.lastName}</td>
                                    <td>{item.email}</td>
                                    <td>{item.roles[0].name}</td>
                                    {/* <th className={styles.Action}><i onClick={dispatch(getLogs())}>Work Log</i></th> */}
                                    <td className={styles.Action}><i onClick={() => delcheck(item.id)}><Trash /></i></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default UserList
