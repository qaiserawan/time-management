import React, {useEffect, useState} from 'react'
import UserCard from '../../../components/UserCard/UserCard'
// import UserList from '../List/UserList'
import styles from '../../../components/Dashboard/Dashboard.module.css'
import axios from 'axios'
// import { getUserLogs } from '../../../store/actions/AdminActions'
import { useParams } from 'react-router'
import Header from '../../../components/Header/Header'


const UserLogs = () => {
    // const logData = useSelector(state => state.userReducer)
    
    // const dispatch = useDispatch()
    const {id}  = useParams();
    // alert("ID at next page:", id)
    let userID = id.split(":")[1];
    const [logData, setLogData] = useState([])
    console.log("Log Data:", logData);
    // console.log("ID is", userID)
    // console.log("Data in log" + logs.logDate)
    useEffect(() => {
        axios({
            method: 'get',
            url: `http://34.210.129.167/api/user/${userID}/work-logs`,
            headers: {
              'Authorization': `Bearer  ${localStorage.getItem('token')}` 
            }
          })
          .then((response) => {
            // console.log("Reesponseee", response)
            setLogData(response.data.workLogs.data)
          })
        //   .catch((error) => {
        //     console.error('There was an error!', error)
        //   })
    }, [])
    return (
        <div>
            <Header />
            <div className="container">
            {logData.userLog ? <h3>User Work Log</h3> :  <h1>User has no logs</h1> }
                <div className={styles.CardsList}>
                    {   
                        logData?.userLog?.map((item) => {
                            return( 
                                <UserCard date= {item.log_date} description = {item.description} time = {item.hours} color={item.hours >= 8  ? "green" : "red"}/>
                            )
                        })
                    }
                    {/* <UserCard date="sdasd" description="dasdas" time="asdas" /> */}
                </div>
            </div>
        </div>
    )
}

export default UserLogs
