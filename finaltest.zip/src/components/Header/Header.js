import React from 'react'
import styles from './Header.module.css'
import logo from '../../assets/img/logo.png'
// import user from '../../assets/img/user.png'
// import SignIn from '../SignIn/SignIn'
import Logout from '../Widgets/Logout'
// import SignUp from '../SignUp/SignUp'
// import SearchBar from '../Widgets/SearchBar'

const Header = () => {
    const isLoggedIn = true
    var login;
    // var searchBar;
    if(isLoggedIn === true){
        // searchBar = <SearchBar />
        login =  <Logout />
    }
    else{
        
    }

    return (
        <div>
        <div className={styles.Nav}>
            <div className="container">
                <nav>
                    <div className={styles.NavWrapper}>
                        <div className={styles.Logo}>
                            <img src={logo} alt="Logo" />
                        </div>
                        {login}
                    </div>
                </nav>
            </div>
        </div>
        <div>
            
        </div>
        </div>
    )
}

export default Header
